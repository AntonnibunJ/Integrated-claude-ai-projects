"""Train on data/*.npy. Evaluation is split BY RECORDING, so windows from one take never sit in both train and test
(random splits inflate accuracy to ~99% and hide real-world failure)."""
import glob, os, joblib, numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import classification_report
from tsl import W, win_feat, augment
X, y, g = [], [], []
for gi, f in enumerate(sorted(glob.glob("data/*.npy"))):
    a, lab = np.load(f), os.path.basename(f).split("__")[0]
    for i in range(0, len(a) - W + 1, 2): X.append(a[i:i+W]); y.append(lab); g.append(gi)
X, y, g = np.array(X), np.array(y), np.array(g)
if len(set(y)) < 2: raise SystemExit("Record at least 2 different signs with collect.py first.")
rng = np.random.default_rng(0)
def fit(Xw, yw, copies=4):
    Xa = [win_feat(w) for w in Xw] + [win_feat(augment(w, rng)) for w in Xw for _ in range(copies)]
    ya = list(yw) + [l for l in yw for _ in range(copies)]
    m = make_pipeline(StandardScaler(), MLPClassifier((256, 128), alpha=1e-3, max_iter=300, early_stopping=True, random_state=0))
    return m.fit(np.array(Xa), ya)
if len(set(g)) >= 4:
    tr, te = next(GroupShuffleSplit(1, test_size=.25, random_state=0).split(X, y, g))
    m = fit(X[tr], y[tr])
    print(classification_report(y[te], m.predict(np.array([win_feat(w) for w in X[te]])), zero_division=0))
else: print("Too few recordings for an honest hold-out test - record more takes per sign.")
joblib.dump(fit(X, y), "model.joblib"); print("Saved model.joblib")
