"""Record your own signs.  n/p = next/previous sign, r = record 4 s, q = quit.
Tip: ~8+ recordings per sign, vary lighting, distance, angle, background, and (ideally) people."""
import os, time, cv2, numpy as np
from tsl import ALL, detector, frame_feat, draw
SECS = 4
os.makedirs("data", exist_ok=True)
count = lambda l: sum(f.startswith(l + "__") for f in os.listdir("data"))
i, rec, frames = 0, None, []
cap, det = cv2.VideoCapture(0), detector()
while True:
    ok, img = cap.read()
    if not ok: break
    img = cv2.flip(img, 1); res = det.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    for hl in (res.multi_hand_landmarks or []): draw(img, hl)
    if rec is not None:
        frames.append(frame_feat(res))
        if time.time() - rec >= SECS:
            a = np.array(frames)
            if (np.abs(a).sum(1) > 0).mean() > .7: np.save(f"data/{ALL[i]}__{int(time.time())}.npy", a)
            else: print("Hand not visible enough - recording discarded")
            rec, frames = None, []
    col = (0, 0, 255) if rec is not None else (0, 200, 0)
    cv2.putText(img, f"[{ALL[i]}] saved:{count(ALL[i])}  {'RECORDING' if rec else 'n/p r q'}", (10, 30), 0, .8, col, 2)
    cv2.imshow("collect", img); k = cv2.waitKey(1) & 255
    if k == ord("q"): break
    if k == ord("n"): i = (i + 1) % len(ALL)
    if k == ord("p"): i = (i - 1) % len(ALL)
    if k == ord("r") and rec is None: rec, frames = time.time(), []
