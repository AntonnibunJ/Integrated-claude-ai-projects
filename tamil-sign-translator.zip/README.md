# Tamil Sign Translator (hand sign -> Tamil text + voice)

Python 3.9-3.12, any PC with a webcam.

    pip install -r requirements.txt
    python collect.py     # record each sign (n/p switch sign, r records 4 s, q quits)
    python train.py       # prints an honest hold-out report, saves model.joblib
    python app.py         # live Tamil text + Speak button (voice also via the 'speak' sign)

Signs are ASCII ids (ka, aa, vanakkam...) mapped to Tamil in tsl.py - edit WORDS / the sign list to match
the Tamil Sign Language chart you follow. Sign a consonant then a vowel (ka + aa -> கா); 'pulli' adds ்.
Voice needs internet for gTTS (cached afterwards); offline it falls back to an installed Tamil system voice.
Record a 'rest' sign (relaxed hand) so idle hands are not misread.
