"""Shared pieces: Tamil vocabulary + composition rules, hand features, augmentation."""
import numpy as np

W = 15  # frames per window (~0.5 s) -> handles static letters AND moving signs

VOWELS = {"a":"அ","aa":"ஆ","i":"இ","ii":"ஈ","u":"உ","uu":"ஊ","e":"எ","ee":"ஏ","ai":"ஐ","o":"ஒ","oo":"ஓ","au":"ஔ"}
SIGNS  = {"aa":"ா","i":"ி","ii":"ீ","u":"ு","uu":"ூ","e":"ெ","ee":"ே","ai":"ை","o":"ொ","oo":"ோ","au":"ௌ"}
CONS = dict(zip("ka nga ca nya ta na tha nha pa ma ya ra la va zha lla rra nna".split(), "கஙசஞடணதநபமயரலவழளறன"))
WORDS = {"vanakkam":"வணக்கம்","nandri":"நன்றி","aam":"ஆம்","illai":"இல்லை","udhavi":"உதவி","thanneer":"தண்ணீர்"}
CTRL = ["space", "delete", "pulli", "speak", "clear", "rest"]
ALL = list(VOWELS) + list(CONS) + ["aytham"] + list(WORDS) + CTRL
CONS_CHARS = set(CONS.values())

def apply(text, k):
    """Tamil composition: sign consonant (ka) then vowel (aa) -> கா. 30 signs build all 247 letters."""
    last = text[-1] if text else ""
    if k == "rest": return text
    if k == "delete": return text[:-1]
    if k == "clear": return ""
    if k == "space": return text + " "
    if k == "pulli": return text + "\u0bcd" if last in CONS_CHARS else text
    if k in CONS: return text + CONS[k]
    if k == "aytham": return text + "ஃ"
    if k in VOWELS:
        if last in CONS_CHARS:
            return text if k == "a" else text + SIGNS[k]   # inherent 'a' needs no sign
        return text + VOWELS[k]
    if k in WORDS: return text + ("" if not text or text.endswith(" ") else " ") + WORDS[k] + " "
    return text

# ---------- hand features (MediaPipe landmarks: light/background/skin-tone independent) ----------
def detector():
    import mediapipe as mp
    return mp.solutions.hands.Hands(max_num_hands=2, min_detection_confidence=0.6, min_tracking_confidence=0.5)

def draw(img, hl):
    import mediapipe as mp
    mp.solutions.drawing_utils.draw_landmarks(img, hl, mp.solutions.hands.HAND_CONNECTIONS)

def frame_feat(res):
    """Per hand slot (Left/Right): 63 wrist-relative, size-normalised coords + 2 wrist position."""
    f = np.zeros(130, np.float32)
    if res.multi_hand_landmarks:
        for lm, hd in zip(res.multi_hand_landmarks, res.multi_handedness):
            s = 0 if hd.classification[0].label == "Left" else 1
            p = np.array([[l.x, l.y, l.z] for l in lm.landmark], np.float32)
            wrist = p[0, :2].copy(); q = p - p[0]
            q /= np.linalg.norm(q[9]) + 1e-6          # scale-invariant (hand size / distance)
            f[s*65:s*65+63] = q.ravel(); f[s*65+63:s*65+65] = wrist
    return f

def win_feat(w):
    """Window (W,130) -> vector. Wrist position made relative to window mean (position-invariant, motion kept)."""
    w = np.array(w, np.float32)
    for s in (0, 1):
        on = np.abs(w[:, s*65:s*65+63]).sum(1) > 0
        c = slice(s*65+63, s*65+65)
        if on.any(): w[on, c] -= w[on, c].mean(0)
        w[~on, c] = 0
    return w.ravel()

def augment(w, r):
    """Mirror (left-handed signers), rotation, scale, noise."""
    w = w.copy().reshape(W, 2, 65)
    if r.random() < .5:
        w[:, :, 0:63:3] *= -1
        w[:, :, 63] = np.where(w[:, :, 63] != 0, 1 - w[:, :, 63], 0)
        w = w[:, ::-1].copy()
    a = np.deg2rad(r.uniform(-15, 15)); c, s = np.cos(a), np.sin(a)
    x, y = w[:, :, 0:63:3].copy(), w[:, :, 1:63:3].copy()
    w[:, :, 0:63:3], w[:, :, 1:63:3] = c*x - s*y, s*x + c*y
    on = np.abs(w[:, :, :63]) > 0
    w[:, :, :63] = w[:, :, :63] * r.uniform(.9, 1.1) + r.normal(0, .01, on.shape) * on
    return w.reshape(W, 130)
