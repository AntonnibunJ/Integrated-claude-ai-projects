"""Live hand sign -> Tamil text + voice."""
import os, hashlib, threading, collections, tkinter as tk, tkinter.font as tkf
import cv2, joblib, numpy as np
from PIL import Image, ImageTk
from tsl import W, apply, detector, draw, frame_feat, win_feat
THRESH, MARGIN, HOLD, REARM = 0.85, 0.30, 10, 5   # confidence, lead over 2nd best, hold frames, re-arm frames

def speak(text):
    def run():
        try:                                   # online Tamil voice (cached after first use)
            from gtts import gTTS; import pygame
            os.makedirs("tts_cache", exist_ok=True)
            p = "tts_cache/" + hashlib.md5(text.encode()).hexdigest() + ".mp3"
            if not os.path.exists(p): gTTS(text, lang="ta").save(p)
            pygame.mixer.init(); pygame.mixer.music.load(p); pygame.mixer.music.play()
        except Exception:                      # offline fallback: an installed Tamil system voice
            try:
                import pyttsx3; e = pyttsx3.init()
                for v in e.getProperty("voices"):
                    if "tamil" in v.name.lower() or "ta" in [str(l).lower() for l in v.languages]: e.setProperty("voice", v.id); break
                e.say(text); e.runAndWait()
            except Exception as ex: print("Voice failed:", ex)
    threading.Thread(target=run, daemon=True).start()

class App:
    def __init__(s, root):
        if not os.path.exists("model.joblib"): raise SystemExit("Run collect.py then train.py first.")
        s.root, s.model = root, joblib.load("model.joblib"); s.cls = s.model.classes_
        s.det, s.cap = detector(), cv2.VideoCapture(0)
        fam = next((f for f in ("Nirmala UI", "Latha", "Noto Sans Tamil", "InaiMathi", "Tamil Sangam MN", "Lohit Tamil") if f in set(tkf.families())), "TkDefaultFont")
        root.title("Tamil Sign Translator")
        s.vid = tk.Label(root); s.vid.grid(row=0, column=0, rowspan=3, padx=6, pady=6)
        s.tv, s.sv = tk.StringVar(), tk.StringVar(); s.t = ""
        tk.Label(root, textvariable=s.tv, font=(fam, 28), wraplength=420, width=22, height=5, bg="white", relief="sunken", anchor="nw", justify="left").grid(row=0, column=1, padx=6, pady=6)
        tk.Label(root, textvariable=s.sv, font=("Arial", 12)).grid(row=1, column=1)
        bar = tk.Frame(root); bar.grid(row=2, column=1)
        for t, c in (("Speak", s.say), ("Backspace", lambda: s.set(apply(s.t, "delete"))), ("Clear", lambda: s.set(""))):
            tk.Button(bar, text=t, command=c).pack(side="left", padx=3)
        s.buf, s.cand, s.streak, s.last, s.idle = collections.deque(maxlen=W), None, 0, None, 0
        root.protocol("WM_DELETE_WINDOW", lambda: (s.cap.release(), root.destroy())); s.step()
    def set(s, v): s.t = v; s.tv.set(v)
    def say(s): s.t.strip() and speak(s.t)
    def commit(s, k): s.say() if k == "speak" else s.set(apply(s.t, k))
    def step(s):
        ok, img = s.cap.read()
        if ok:
            img = cv2.flip(img, 1); res = s.det.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            s.buf.append(frame_feat(res)); has = bool(res.multi_hand_landmarks)
            for hl in (res.multi_hand_landmarks or []): draw(img, hl)
            cand, info = None, "show a sign"
            if has and len(s.buf) == W:
                p = s.model.predict_proba(win_feat(s.buf)[None])[0]; o = np.argsort(p)[::-1]
                info = f"{s.cls[o[0]]} {p[o[0]]:.0%}"
                if p[o[0]] >= THRESH and p[o[0]] - p[o[1]] >= MARGIN: cand = s.cls[o[0]]   # else "unknown": no guess
            if cand and cand != "rest":
                s.idle, s.streak = 0, (s.streak + 1 if cand == s.cand else 1)
                if s.streak >= HOLD and cand != s.last: s.commit(cand); s.last = cand
            else:
                s.idle += 1; s.streak = 0
                if s.idle >= REARM: s.last = None             # hand lowered/rest -> same sign can repeat
            s.cand = cand; s.sv.set(f"{info}   hold {min(s.streak, HOLD)}/{HOLD}")
            im = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)).resize((480, 360)))
            s.vid.im = im; s.vid.config(image=im)
        s.root.after(15, s.step)

root = tk.Tk(); App(root); root.mainloop()
